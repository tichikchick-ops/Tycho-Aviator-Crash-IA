"""Bot Telegram de suivi statistique Aviator/Crash.
Les résultats doivent être saisis manuellement. Aucune prédiction ni garantie de gain.
Python 3.10+ ; dépendance : python-telegram-bot==21.10
"""
import os, json, logging
from datetime import datetime, timezone
from pathlib import Path
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
DATA_FILE = Path(os.getenv("BOT_DATA_FILE", "historique.json"))
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")


def load_data():
    if DATA_FILE.exists():
        try:
            return json.loads(DATA_FILE.read_text(encoding="utf-8"))
        except Exception:
            logging.exception("Impossible de lire le fichier de données")
    return []


def save_data(rows):
    DATA_FILE.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = (
        "Bienvenue dans Crash Stats Benin 📊\n\n"
        "Je conserve les multiplicateurs que tu saisis et calcule des statistiques descriptives. "
        "Je ne prédis pas le prochain résultat et ne garantis aucun gain.\n\n"
        "/ajouter 1.42 — enregistrer un multiplicateur observé\n"
        "/stats — résumé des données enregistrées\n"
        "/historique — 10 derniers résultats\n"
        "/analyse — fréquences descriptives\n"
        "/risques — rappel de sécurité\n"
        "/aide — afficher les commandes"
    )
    await update.effective_message.reply_text(msg)

async def aide(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await start(update, context)

async def ajouter(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.effective_message.reply_text("Utilisation : /ajouter 1.42\nSaisis le multiplicateur réellement observé.")
        return
    try:
        value = float(context.args[0].replace(",", ".").lower().replace("x", ""))
        if value < 1 or value > 100000:
            raise ValueError
    except ValueError:
        await update.effective_message.reply_text("Valeur invalide. Exemple : /ajouter 1.42")
        return
    rows = load_data()
    rows.append({"value": value, "time": datetime.now(timezone.utc).isoformat(), "user_id": update.effective_user.id if update.effective_user else None})
    save_data(rows)
    await update.effective_message.reply_text(f"Résultat enregistré : {value:.2f}x\nTotal enregistré : {len(rows)}\nCe résultat ne permet pas de prédire le suivant.")

async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rows = load_data()
    if not rows:
        await update.effective_message.reply_text("Aucune donnée. Ajoute un résultat observé avec /ajouter 1.42")
        return
    vals = [float(r["value"]) for r in rows]
    avg = sum(vals) / len(vals)
    await update.effective_message.reply_text(
        f"📊 Résumé descriptif\nRésultats saisis : {len(vals)}\n"
        f"Moyenne observée : {avg:.2f}x\nMinimum : {min(vals):.2f}x\nMaximum : {max(vals):.2f}x\n\n"
        "Échantillon saisi manuellement : il peut être incomplet et ne prédit pas les prochains tours."
    )

async def historique(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rows = load_data()[-10:]
    if not rows:
        await update.effective_message.reply_text("Historique vide. Utilise /ajouter 1.42")
        return
    lines = [f"{i}. {r['value']:.2f}x — {r['time'][:19].replace('T', ' ')} UTC" for i, r in enumerate(reversed(rows), 1)]
    await update.effective_message.reply_text("🗂 10 derniers résultats enregistrés\n" + "\n".join(lines))

async def analyse(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rows = load_data()
    if not rows:
        await update.effective_message.reply_text("Pas assez de données. Enregistre les résultats observés avec /ajouter 1.42")
        return
    vals = [float(r["value"]) for r in rows]
    n = len(vals)
    bands = [("1.00–1.49x", 1, 1.5), ("1.50–1.99x", 1.5, 2), ("2.00–4.99x", 2, 5), ("5.00x et plus", 5, float('inf'))]
    out = [f"🔎 Fréquences sur {n} résultats saisis"]
    for label, lo, hi in bands:
        count = sum(1 for v in vals if lo <= v < hi)
        out.append(f"{label} : {count} ({count/n*100:.1f}%)")
    out.append("\nFréquences historiques uniquement : elles ne donnent pas la probabilité certaine du prochain résultat.")
    await update.effective_message.reply_text("\n".join(out))

async def risques(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.effective_message.reply_text(
        "⚠️ Rappel de sécurité\n"
        "• Aucun bot ne connaît avec certitude le prochain multiplicateur.\n"
        "• Ne paie pas pour des signaux garantis et ne partage jamais ton mot de passe ni tes codes.\n"
        "• Ne mise pas l'argent nécessaire aux besoins essentiels et ne poursuis pas les pertes.\n"
        "• Ce bot ne se connecte pas à 1xBet et ne place aucun pari."
    )

async def post_init(app: Application):
    logging.info("Bot démarré. Polling Telegram actif.")


def main():
    if not TOKEN:
        raise SystemExit("Jeton manquant. Définis la variable TELEGRAM_BOT_TOKEN avec le jeton reçu de @BotFather.")
    app = Application.builder().token(TOKEN).post_init(post_init).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("aide", aide))
    app.add_handler(CommandHandler("ajouter", ajouter))
    app.add_handler(CommandHandler("stats", stats))
    app.add_handler(CommandHandler("historique", historique))
    app.add_handler(CommandHandler("analyse", analyse))
    app.add_handler(CommandHandler("risques", risques))
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
