CRASH STATS BENIN — GUIDE RAPIDE

CE QUE FAIT LE BOT
- /start et /aide : instructions
- /ajouter 1.42 : enregistre un multiplicateur observé manuellement
- /stats : moyenne, minimum, maximum et nombre de résultats saisis
- /historique : affiche les 10 dernières saisies
- /analyse : fréquences descriptives des résultats saisis
- /risques : rappel de sécurité

LIMITES IMPORTANTES
Ce bot n'est pas affilié à 1xBet, ne se connecte pas à un compte 1xBet et ne place aucun pari. Il ne prédit pas le prochain résultat et ne garantit aucun gain. Les données sont saisies manuellement par l'utilisateur. Le fichier historique.json est créé automatiquement dans le dossier de travail.

INSTALLATION
1. Dans Telegram, ouvre https://t.me/BotFather
2. Envoie /newbot et suis les instructions. Copie le jeton reçu. Ne le partage avec personne.
3. Sur un ordinateur ou un hébergement Python, installe Python 3.10 ou plus récent.
4. Dans le dossier du bot, exécute : pip install -r requirements.txt
5. Configure la variable d'environnement TELEGRAM_BOT_TOKEN avec le jeton. Ne mets pas le jeton dans un message public ni dans une capture d'écran.
6. Lance : python bot.py
7. Ouvre ton bot Telegram et envoie /start.

POUR L'UTILISER SUR TÉLÉPHONE
Tu peux créer le bot depuis ton téléphone, mais l'exécution continue nécessite un service qui accepte Python et reste actif. Les offres gratuites peuvent dormir, imposer des limites ou changer. Vérifie les conditions du fournisseur avant de compter sur un fonctionnement 24/7. Ne fournis jamais le jeton à un inconnu.

DÉPANNAGE
- « Jeton manquant » : configure TELEGRAM_BOT_TOKEN dans l'environnement d'exécution.
- « Conflict: terminated by other getUpdates request » : le bot tourne probablement deux fois ; arrête l'autre instance.
- Les données sont enregistrées localement dans historique.json ; sauvegarde ce fichier si ton hébergement est éphémère.
